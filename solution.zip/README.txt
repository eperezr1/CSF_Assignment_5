Team Members:
Amy Lin
Emily Perez-Rodriguez

CONTRIBUTIONS:
In Milestone 1, Emily implemented the Message and MessageSerialization functionalities.
Amy implemented the Table and ValueStack functionalities. For the client programs,
Amy implemented get_value, and Emily implemented set_value. We worked together to implement
and debug incr_value. 